Name: Anmol Lal
e-mail: alal30@gatech.edu